/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.reservacioncanchas;

/**
 *
 * @author USER
 */
public class ReservacionCanchas {

    public static void main(String[] args) {
        FrmMenu.main(args);
    }
}
